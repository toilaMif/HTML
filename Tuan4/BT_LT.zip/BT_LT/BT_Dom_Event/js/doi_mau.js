function Red(){
    document.getElementById("main").style.backgroundColor="red";
}
function Green(){
    document.getElementById("main").style.backgroundColor="Green";
}
function Blue(){
    document.getElementById("main").style.backgroundColor="Blue";
}